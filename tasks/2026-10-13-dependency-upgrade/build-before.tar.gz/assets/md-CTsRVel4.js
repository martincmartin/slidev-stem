import{H as e,L as t,Q as n,T as r,Z as i,_ as a,_t as o,b as s,g as c,gt as l,v as u,vt as d}from"./modules/shiki-VnNeezdK.js";import{ht as f,m as p,p as m}from"./index-CGsMjDgp.js";import{t as h}from"./slidev/default-DuKmoEmi.js";import{r as g,t as _}from"./instance-CEeWln86.js";import{t as v}from"./WatchCallout-Baec5PkH.js";var y=f({__name:`slides.md__slidev_5`,setup(f){let{$slidev:y,$nav:b,$clicksContext:x,$clicks:S,$page:C,$renderContext:w,$frontmatter:T}=p();x.setup();let E=g(_,p().$frontmatter);return(f,p)=>{let g=v,_=e(`click`);return t(),a(h,d(r(l(m)(l(T),4))),{default:i(()=>[p[3]||=c(`h1`,null,`Escapement`,-1),p[4]||=c(`p`,null,`From back-and-forth to turning in one direction`,-1),u(` The newest callout is the focus: while the pallet's (click 2) and then the
jewel's (click 3) is the newest, the callouts before it dim. At click 4 the
balance swings again, the jewel's leader fades, and all three come back.

The wheel's and the pallet's leaders end LEADER_GAP px outside their parts
(docs/watch.md, "The callouts").
`),c(`div`,{class:o([`esc-callouts`,{"esc-focus-pallet":l(S)===2,"esc-focus-jewel":l(S)===3}])},[n((t(),a(g,{keyword:``,class:`esc-wheel`,bent:``,to:l(E).escape,stop:l(10),clear:[l(E).escapeTips],left:680,top:136},{default:i(()=>[...p[0]||=[c(`span`,{class:`callout-word`},`Wheel`,-1),s(` driven by`,-1),c(`br`,null,null,-1),s(`hidden mechanism`,-1)]]),_:1},8,[`to`,`stop`,`clear`])),[[_,1]]),n((t(),a(g,{keyword:``,class:`after-watch-fade esc-pallet`,to:l(E).pallet,stop:l(10),clear:l(E).forkOutlines,left:470,top:470},{default:i(()=>[...p[1]||=[c(`span`,{class:`callout-word`},`Pallet`,-1),s(` blocks wheel`,-1)]]),_:1},8,[`to`,`stop`,`clear`])),[[_,2]]),n((t(),a(g,{keyword:``,class:`after-balance-rest`,to:l(E).jewel,"show-leader":l(S)<4,left:330,top:136},{default:i(()=>[...p[2]||=[c(`span`,{class:`callout-word`},`Jewel`,-1),s(` strikes pallet`,-1)]]),_:1},8,[`to`,`show-leader`])),[[_,3]])],2),u(`
"Force (unseen) trying to turn wheel"

"Pallet blocks wheel"

"Jewel strikes pallet"

"Pallet strikes Jewel"
`),u(`
The camera zooms out, with only the balance wheel and the hairspring on the screen. Then the roller, its impulse jewel, the pallet fork and the escape wheel fade in.
`)]),_:1},16)}}},[[`__scopeId`,`data-v-fc79e251`]]);export{y as default};