// The little of Slidev's client API that the watch's layers use. tsconfig.json
// maps "@slidev/client" here, because importing the real one makes `vue-tsc`
// check Slidev's own sources, which are TypeScript and do not pass our strict
// settings.

import type { Ref } from "vue";

export interface SlideRoute {
  /** The slide's number (1-based). */
  no: number;
  meta: { slide?: { frontmatter?: Record<string, unknown>; title?: string } };
}

export function useNav(): {
  isPrintMode: Ref<boolean>;
  currentSlideNo: Ref<number>;
  slides: Ref<SlideRoute[]>;
};

/** `$frontmatter` is a reactive object; `$renderContext` is the way the slide
 *  is drawn: "slide", "presenter", "overview", "print"... */
export function useSlideContext(): {
  $frontmatter: Record<string, unknown>;
  $renderContext: Ref<string>;
  /** This slide's number (1-based). */
  $page: Ref<number>;
  /** The click that this render of the slide shows: the page's own, in an
   *  export with one page for each click. */
  $clicks: Ref<number>;
};
