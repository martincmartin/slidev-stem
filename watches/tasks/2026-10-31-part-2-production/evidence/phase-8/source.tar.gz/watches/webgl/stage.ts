// A live stage: a canvas that moves its camera from view to view, fades
// meshes in and out, tilts, and runs a model. It knows
// nothing about what the scene shows: the model does.
//
// THE ORDER AND THE FLASH are the timeline's (timeline.ts): the stage has the
// renderer, the model and the frame loop, and asks the timeline what to draw.
//
// A MODEL'S STORY. A model may tell a story of its own at a change (in the
// watch, a key that winds the mainspring). It starts when the stage's change
// ends (`Model.show`'s `after`). The story can show meshes that no state
// names, at an opacity (`Model.extra`): one fade at a time, so it fades them
// while the timeline does not fade; if both fade at once, the story's meshes
// show whole, or not at all.
//
// A stage owns its renderer and its frame loop: `dispose()` stops both and
// frees the renderer's GL objects.
//
// AN ERROR. If a frame throws (a model's bad matrix, a frame that breaks the
// renderer's contract), the loop stops: the stage does not continue after a
// frame that it could not finish. The error goes to the browser's console;
// `start()` runs the loop again.

import { check } from "./checked.ts";
import { Renderer } from "./renderer.ts";
import type { Place } from "./renderer.ts";
import { FLASH_INKS } from "./scene.ts";
import type {
  CameraAngles,
  Group,
  Mesh,
  Palette,
  CameraPose,
  Scene,
  SlideRect,
} from "./scene.ts";
import type { Matrix4 } from "./math.ts";
import { Timeline } from "./timeline.ts";
import type { StageState, Values } from "./timeline.ts";

/** Meshes that a model's story shows besides the state's, at an opacity. */
export interface Extra {
  readonly meshes: ReadonlySet<Mesh>;
  /** 0 to 1. */
  readonly opacity: number;
}

/** What the scene shows and moves. */
export interface Model<ModelState> {
  /** A new state for the model; `instantly` for a slide reached directly.
   *  `after` (ms): when the stage's change ends, for a story that plays
   *  forward. */
  show(state: ModelState, now: number, instantly: boolean, after: number): void;
  /** The world matrix of each group at `now`, for a frame whose camera is
   *  `pose` (a part that faces the camera turns with it); it updates
   *  dynamic meshes. */
  frame(
    now: number,
    renderer: Renderer,
    pose: CameraPose,
  ): Map<Group, Float32Array>;
  /** The story's meshes at `now`, or `null`. */
  extra?(now: number): Extra | null;
  /** When the story's moves end (ms), or `now`. */
  endAt?(now: number): number;
  /** Whether the story moves at `now`. */
  moving?(now: number): boolean;
  /** What the model is doing, for the measurement scripts. */
  phase(now: number): string;
}

/** The matrices of groups that follow the camera, for a frame at `angles`:
 *  a part that faces the camera, such as a globe's disc. */
export type PoseGroups = (angles: CameraAngles) => Map<Group, Matrix4>;

/** `model`, with the matrices of `groups` in each of its frames too: a
 *  scene of two parts, one of which has no state of its own. */
export function withPoseGroups<ModelState>(
  model: Model<ModelState>,
  groups: PoseGroups,
): Model<ModelState> {
  return {
    show: (state, now, instantly, after) => {
      model.show(state, now, instantly, after);
    },
    frame: (now, renderer, pose) =>
      new Map([...model.frame(now, renderer, pose), ...groups(pose)]),
    ...(model.extra ? { extra: (now) => model.extra?.(now) ?? null } : {}),
    ...(model.endAt ? { endAt: (now) => model.endAt?.(now) ?? now } : {}),
    ...(model.moving ? { moving: (now) => model.moving?.(now) ?? false } : {}),
    phase: (now) => model.phase(now),
  };
}

/** The element's size on the screen, in device px. Slidev scales the slide
 *  with a CSS transform, which `clientWidth` leaves out: the bounding box has
 *  it. */
export function deviceSize(element: Element): [number, number] {
  const ratio = window.devicePixelRatio || 1;
  const { width, height } = element.getBoundingClientRect();
  return [
    Math.max(1, Math.round(width * ratio)),
    Math.max(1, Math.round(height * ratio)),
  ];
}

/** The frames that the log keeps: 10 minutes at 60 frames a second. When it
 *  has twice this many, it drops the oldest half, so that a long run does
 *  not grow without end. */
export const FRAME_LOG_LIMIT = 36_000;

/** What the measurement scripts read: each frame's start, JS time and phase,
 *  for the last FRAME_LOG_LIMIT frames or more. */
export interface FrameLog {
  starts: number[];
  drawTimes: number[];
  phases: string[];
  /** [start, "width x height"] at each change of the drawing's size. */
  sizes: [number, string][];
}

/** The timeline's fade, with the story's meshes: whole, or as the fade if
 *  the timeline does not fade. While both fade, they show whole from half
 *  their opacity. */
function withExtra(
  values: Values,
  extra: Extra | null | undefined,
): Pick<Values, "keep" | "fade" | "rest"> {
  const { keep, fade, rest } = values;
  if (!extra || extra.opacity <= 0) return { keep, fade, rest };
  const whole = new Set([...keep, ...extra.meshes]);
  if (extra.opacity >= 1) return { keep: whole, fade, rest };
  if (fade.size === 0) return { keep, fade: extra.meshes, rest: extra.opacity };
  return { keep: extra.opacity >= 0.5 ? whole : keep, fade, rest };
}

/** How a view of the article draws, besides a stage's frame (shared.ts). */
export interface ViewDrawing {
  /** Meshes drawn in the flash's colours for as long as they show, as a
   *  steady flash. Default: none. */
  readonly marked?: ReadonlySet<Mesh>;
  /** The part of the slide that the view shows (`Frame.crop`). */
  readonly crop?: SlideRect;
  /** Where the picture goes on the renderer's canvas (`Renderer.render`). */
  readonly place?: Place;
}

/** Called after each frame that a stage or a view draws, with the camera
 *  that it drew with and its time: a layer over the canvas moves its marks
 *  with it (`planeOnSlide` in renderer.ts), in the same animation frame. */
export type FrameListener = (pose: CameraPose, now: number) => void;

/** Draw one frame of a timeline and a model at `now`, `size` device px,
 *  with the renderer: the stage's frame, and each view's on a shared
 *  renderer (shared.ts), with `drawing`. Returns the camera it drew with. */
export function drawFrame<ModelState>(
  renderer: Renderer,
  timeline: Timeline,
  model: Model<ModelState>,
  now: number,
  size: [number, number],
  drawing: ViewDrawing = {},
): CameraPose {
  const marked = drawing.marked ?? new Set<Mesh>();
  const values = timeline.valuesAt(now);
  const flashing = timeline.flashingAt(now);
  const recoloured =
    flashing && marked.size > 0
      ? new Set([...flashing, ...marked])
      : (flashing ?? (marked.size > 0 ? marked : null));
  const pose = { view: values.view, tilt: values.tilt, turn: values.turn };
  const groupMatrices = model.frame(now, renderer, pose);
  const { keep, fade, rest } = withExtra(values, model.extra?.(now));
  renderer.render(
    {
      view: values.view,
      tilt: values.tilt,
      turn: values.turn,
      groupMatrices,
      keep,
      fade,
      rest,
      ...(recoloured
        ? { recolour: { meshes: recoloured, inks: FLASH_INKS } }
        : {}),
      dim: values.dim,
      size,
      ...(drawing.crop ? { crop: drawing.crop } : {}),
    },
    drawing.place,
  );
  return pose;
}

export class Stage<ModelState> {
  readonly canvas: HTMLCanvasElement;
  readonly renderer: Renderer;
  readonly log: FrameLog = { starts: [], drawTimes: [], phases: [], sizes: [] };
  private readonly model: Model<ModelState>;
  /** The pending animation frame, while the stage runs. */
  private request: number | null = null;
  private disposed = false;
  private readonly timeline: Timeline;
  private readonly listeners = new Set<FrameListener>();

  constructor(
    canvas: HTMLCanvasElement,
    scene: Scene,
    palette: Palette,
    model: Model<ModelState>,
  ) {
    this.canvas = canvas;
    this.model = model;
    this.timeline = new Timeline(scene.slide);
    this.renderer = new Renderer(canvas, scene, palette);
  }

  /** Go to a slide's state: at once, or one channel at a time from where the
   *  camera and the fade are now. The timeline controls the flash order.
   *  Returns the seconds until the flash ends, or 0 if there is none. */
  show(state: StageState, modelState: ModelState, instantly = false): number {
    check(!this.disposed, "the stage is disposed");
    const now = performance.now();
    const atOnce = instantly || !this.timeline.hasState;
    const flashSeconds = this.timeline.show(state, now, atOnce);
    this.model.show(modelState, now, atOnce, this.timeline.endAt(now));
    return flashSeconds;
  }

  /** The flashed meshes, if the flash is on at `now`. */
  flashingAt(now: number): ReadonlySet<Mesh> | null {
    return this.timeline.flashingAt(now);
  }

  /** Each channel's value at `now`. */
  valuesAt(now: number): Values {
    return this.timeline.valuesAt(now);
  }

  /** Whether a state has been shown yet. */
  get hasState(): boolean {
    return this.timeline.hasState;
  }

  /** Whether a channel moves, the flash runs, or the model's story moves, at
   *  `now`. */
  movingAt(now: number): boolean {
    return (
      this.timeline.phaseAt(now) !== null || (this.model.moving?.(now) ?? false)
    );
  }

  /** When the camera's last move ends (ms), or `now` if it does not move. */
  viewEndAt(now: number): number {
    return this.timeline.viewEndAt(now);
  }

  /** When the change ends (ms), with its flash and the model's story, or
   *  `now` if it has. */
  endAt(now: number): number {
    return Math.max(this.timeline.endAt(now), this.model.endAt?.(now) ?? now);
  }

  /** The flight that runs at `now`, and the share of its time gone, or
   *  null. */
  flightAt(now: number): ReturnType<Timeline["flightAt"]> {
    return this.timeline.flightAt(now);
  }

  /** What is moving at `now`: the flash, a channel, or the model's phase. */
  phaseAt(now: number): string {
    return this.timeline.phaseAt(now) ?? this.model.phase(now);
  }

  /** Draw a frame at each animation frame, until `stop()`. */
  start(): void {
    check(!this.disposed, "the stage is disposed");
    check(this.timeline.hasState, "show a state before the stage starts");
    this.request ??= requestAnimationFrame(this.frame);
  }

  stop(): void {
    if (this.request !== null) cancelAnimationFrame(this.request);
    this.request = null;
  }

  /** Draw in `palette`'s colours from the next frame. */
  setPalette(palette: Palette): void {
    check(!this.disposed, "the stage is disposed");
    this.renderer.setPalette(palette);
  }

  /** Call `listener` after each frame, until the returned function is
   *  called. If it throws, the frame throws (see the top). */
  onFrame(listener: FrameListener): () => void {
    check(!this.disposed, "the stage is disposed");
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /** Stop, and free the renderer. Calling it again does nothing. */
  dispose(): void {
    this.stop();
    this.renderer.dispose();
    this.listeners.clear();
    this.disposed = true;
  }

  private trimLog(): void {
    const { log } = this;
    if (log.starts.length < 2 * FRAME_LOG_LIMIT) return;
    const oldest = log.starts.length - FRAME_LOG_LIMIT;
    for (const list of [log.starts, log.drawTimes, log.phases]) {
      list.splice(0, oldest);
    }
    const first = log.starts[0] ?? Infinity;
    // keep the size in force at the first kept frame
    const kept = log.sizes.findLastIndex(([start]) => start <= first);
    if (kept > 0) log.sizes.splice(0, kept);
  }

  private readonly frame = (now: number): void => {
    this.request = null;
    const before = performance.now();
    const size = deviceSize(this.canvas);
    const sizeText = size.join(" x ");
    if (this.log.sizes.at(-1)?.[1] !== sizeText) {
      this.log.sizes.push([now, sizeText]);
    }
    const pose = drawFrame(this.renderer, this.timeline, this.model, now, size);
    for (const listener of this.listeners) listener(pose, now);
    this.log.starts.push(now);
    this.log.drawTimes.push(performance.now() - before);
    this.log.phases.push(this.phaseAt(now));
    this.trimLog();
    this.request = requestAnimationFrame(this.frame);
  };
}
