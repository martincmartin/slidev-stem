// Every slide's watch, as slides.md names it: each piece and view exists, at
// every click. A name that is wrong would otherwise throw only when the
// slide shows.

import assert from "node:assert/strict";
import { test } from "node:test";
import { deckSlides } from "./deck.ts";
import { makeArt } from "./art.ts";
import { AtRest, discOutline } from "./at-rest.ts";
import {
  MOVE_WITH_COMMON,
  moveWithBefore,
  stageState,
  stepMove,
  voyageState,
  voyageFor,
  watchState,
} from "./state.ts";
import { anchorPoint } from "../globe/labels.ts";
import type { StepMoveWith, WatchState } from "./state.ts";
import type { Move } from "./navigation.ts";
import type { Mesh, Piece } from "../webgl/scene.ts";
import { Timeline } from "../webgl/timeline.ts";

/** The deck's art: the watch and the globe. */
const { art: watch, globe } = makeArt();
const slides = await deckSlides();

/** The watch's piece called `name`. */
function pieceNamed(name: string): Piece {
  return (
    watch.scene.pieces.find((piece) => piece.name === name) ??
    assert.fail(`no piece ${name}`)
  );
}
const PALLET_FORK = pieceNamed("pallet fork");
const BARREL = pieceNamed("barrel");
const MAINSPRING_STUD = pieceNamed("mainspring stud");

/** Whether the stage shows the piece: what it draws, as the state resolves
 *  it (`stageState`). */
function shows(state: WatchState, piece: Piece): boolean {
  const { shown } = stageState(watch, state);
  return [...piece.meshes].every((mesh) => shown.has(mesh));
}

test("every slide's pieces and view exist, at every click", () => {
  let shown = 0;
  for (const { title, frontmatter } of slides) {
    const clicks = Number(frontmatter["clicks"] ?? 0);
    for (let click = 0; click <= clicks; click++) {
      const state = watchState(frontmatter, click);
      if (!state) continue;
      shown++;
      const stage = stageState(watch, state, moveWithBefore(frontmatter));
      assert.ok(stage.shown.size > 0, `${title} @${String(click)}`);
    }
  }
  assert.ok(shown > 0, "no slide shows the watch");
});

/** A map label's `:on`, `[lon, lat]` in degrees. */
function lonLatOf(text: string): readonly [number, number] {
  const value: unknown = JSON.parse(text);
  if (Array.isArray(value) && value.length === 2) {
    const [lon, lat] = value.map((each: unknown) => each);
    if (typeof lon === "number" && typeof lat === "number") return [lon, lat];
  }
  return assert.fail(`:on="${text}" is not [lon, lat]`);
}

test("every slide's legs, marks and map labels name the story of its view", () => {
  let named = 0;
  for (const { title, frontmatter, content } of slides) {
    const clicks = Number(frontmatter["clicks"] ?? 0);
    for (let click = 0; click <= clicks; click++) {
      const state = watchState(frontmatter, click);
      if (!state) continue;
      // throws for a name that the view's story does not have
      if (
        voyageFor(watch, globe.stories, state, voyageState(frontmatter, click))
      )
        named++;
    }
    // each label's anchor, as MapLabel.vue finds it
    for (const [tag] of content.matchAll(/<MapLabel\b[^>]*>/g)) {
      const attribute = (name: string): string | undefined =>
        new RegExp(`\\s${name}="([^"]*)"`).exec(tag)?.[1];
      const viewName = attribute("view");
      const picture = globe.pictures.find(
        (each) => each.view.name === viewName,
      );
      assert.ok(picture, `${title}: ${tag}`);
      const on = attribute(":on");
      anchorPoint(picture, {
        on: on === undefined ? undefined : lonLatOf(on),
        mark: attribute("mark"),
        leg: attribute("leg"),
      });
      named++;
    }
  }
  assert.ok(named > 0, "no slide names a story's legs, marks or labels");
});

test("no slide spins the train while the pallet fork shows: the escape wheel would turn through its stones", () => {
  for (const { title, frontmatter } of slides) {
    const clicks = Number(frontmatter["clicks"] ?? 0);
    for (let click = 0; click <= clicks; click++) {
      const state = watchState(frontmatter, click);
      if (!state?.spin) continue; // a spin's speed is never 0
      assert.ok(!shows(state, PALLET_FORK), `${title} @${String(click)}`);
    }
  }
});

test("the mainspring winds only where its outer end is held: by the stud, or in the barrel", () => {
  let seen = 0;
  for (const { title, frontmatter } of slides) {
    const clicks = Number(frontmatter["clicks"] ?? 0);
    for (let click = 0; click <= clicks; click++) {
      const state = watchState(frontmatter, click);
      if (!state?.mainspring) continue;
      seen++;
      const holder = shows(state, BARREL)
        ? "barrel"
        : shows(state, MAINSPRING_STUD)
          ? "stud"
          : "nothing";
      const wanted = {
        free: "nothing",
        wound: "stud",
        released: "nothing",
        barrel: "barrel",
        "run down": "barrel",
      }[state.mainspring];
      assert.equal(holder, wanted, `${title} @${String(click)}`);
    }
  }
  assert.ok(seen > 0, "no slide tells the mainspring's story");
});

test("the Gears slide's gears show where they set the picture band: its view is the plan fit that drew them", () => {
  const gears = slides.find((slide) => slide.title === "Gears");
  assert.ok(gears);
  const state = watchState(gears.frontmatter, 0) ?? assert.fail();
  const view = stageState(watch, state).view;
  // the plan fit: the plan's height in 420 px, halfway between the
  // subtitle's baseline (110.7) and the slide's bottom
  const fit = state.fit;
  assert.ok(fit !== "all");
  const extents = watch.scene.pieces
    .filter((piece) => fit.includes(piece.name))
    .map((piece) => watch.extents.get(piece) ?? assert.fail());
  const top = Math.min(...extents.map((extent) => extent.box.top));
  const bottom = Math.max(...extents.map((extent) => extent.box.bottom));
  const scale = 420 / (bottom - top);
  const shiftY = (110.7 + 552) / 2 - (scale * (top + bottom)) / 2;
  assert.ok(
    Math.abs(view.scale / scale - 1) < 1e-4,
    `scale ${String(view.scale)}`,
  );
  assert.ok(
    Math.abs(view.shift[1] - shiftY) < 0.05,
    `shift ${String(view.shift[1])}`,
  );
});

test("no part that a click shows rises through a paper disc that it shows", () => {
  // A paper disc hides only what is under it (docs/watch.md, "Paper discs"):
  // a part that rose through it would show in the wheel's openings. Not the
  // wheel's own parts, such as its arbor. The watch is at rest: a part that
  // turns keeps its heights, but a part that is not round about its axis
  // is checked only where it is at rest.
  const atRest = new AtRest(watch);
  const { scene } = watch;
  const piece = (name: string): Piece =>
    scene.pieces.find((candidate) => candidate.name === name) ??
    assert.fail(name);
  const discOf = (wheel: Piece): Mesh =>
    [...wheel.meshes].find((mesh) => mesh.holdout) ?? assert.fail(wheel.name);
  // the centre arbor rises through the hour wheel's pipe, which hides it
  const allowed = new Map([
    [discOf(piece("hour wheel")), piece("centre arbor").meshes],
  ]);
  // each disc, and the parts that rise through it, found once
  const crossings = scene.meshes
    .filter((mesh) => mesh.holdout)
    .map((disc) => {
      const height = atRest.heights(disc)[0];
      const outline = discOutline(atRest, disc);
      // the wheel's groups; the disc itself is in the watch's
      const own = new Set(
        scene.pieces
          .filter((each) => each.meshes.has(disc))
          .flatMap((each) => [...each.meshes].map((mesh) => mesh.group)),
      );
      own.delete(disc.group);
      const through = scene.meshes.filter((mesh) => {
        // the globe is far from the watch
        if (mesh.holdout || own.has(mesh.group) || globe.piece.meshes.has(mesh))
          return false;
        if (allowed.get(disc)?.has(mesh)) return false;
        const over = outline.heightsOver(atRest.points(mesh));
        return over !== null && over[0] < height && over[1] > height;
      });
      return { disc, through };
    });
  for (const { title, frontmatter } of slides) {
    const clicks = Number(frontmatter["clicks"] ?? 0);
    for (let click = 0; click <= clicks; click++) {
      const state = watchState(frontmatter, click);
      if (!state) continue;
      const { shown } = stageState(watch, state);
      for (const { disc, through } of crossings) {
        if (!shown.has(disc)) continue;
        for (const mesh of through) {
          assert.ok(
            !shown.has(mesh),
            `${title} @${String(click)}: ${mesh.name} rises through ${disc.name}`,
          );
        }
      }
    }
  }
});

/** The camera's phases on a step from `from` to `to`: each channel that
 *  moves it, and for how long (ms), in order, from the timeline at 10 ms. */
function cameraPhases(
  from: WatchState,
  to: WatchState,
  move: Move,
  moveWith: StepMoveWith,
): { channel: string; milliseconds: number }[] {
  const timeline = new Timeline(watch.scene.slide);
  timeline.show(stageState(watch, from, moveWith), 0, true);
  timeline.show(
    stageState(watch, { ...to, move: stepMove(from, to, move) }, moveWith),
    0,
  );
  const phases: { channel: string; milliseconds: number }[] = [];
  for (let time = 0; time < timeline.endAt(0); time += 10) {
    const channel = timeline.phaseAt(time);
    if (channel !== "view" && channel !== "angles" && channel !== "camera") {
      continue;
    }
    const last = phases.at(-1);
    if (last?.channel === channel) last.milliseconds += 10;
    else phases.push({ channel, milliseconds: 10 });
  }
  return phases;
}

test("each step back moves the camera as the step forward does, reversed", () => {
  const places = slides
    .filter(({ frontmatter }) => frontmatter["hide"] !== true)
    .flatMap(({ title, frontmatter }, slide) =>
      Array.from(
        { length: Number(frontmatter["clicks"] ?? 0) + 1 },
        (_, click) => ({ title, frontmatter, slide, click }),
      ),
    );
  let compared = 0;
  for (const [index, earlier] of places.entries()) {
    const later = places[index + 1];
    if (!later) break;
    const before = watchState(earlier.frontmatter, earlier.click);
    const after = watchState(later.frontmatter, later.click);
    if (!before || !after) continue;
    const moveWith =
      earlier.slide === later.slide
        ? MOVE_WITH_COMMON
        : moveWithBefore(later.frontmatter);
    const forward = cameraPhases(before, after, "forward", moveWith);
    const back = cameraPhases(after, before, "back", moveWith);
    assert.deepEqual(
      back,
      forward.toReversed(),
      `${earlier.title} @${String(earlier.click)} and ${later.title} @${String(later.click)}`,
    );
    compared++;
  }
  assert.ok(compared > 0, "no step moves the watch");
});

test("only Recap flashes after the camera finishes, at every stop", () => {
  for (const { title, frontmatter } of slides) {
    for (let click = 0; click <= Number(frontmatter["clicks"] ?? 0); click++) {
      const state = watchState(frontmatter, click);
      if (!state) continue;
      assert.equal(state.flashAfterMove, title === "Recap");
    }
  }
});

test("the step from the Recap slide to the cover's picture moves in order both ways", () => {
  const index = slides.findIndex(({ title }) => title === "Recap");
  const recap = slides[index]?.frontmatter;
  const section = slides[index + 1];
  assert.ok(recap && section?.title === "Changed The World");
  const hairspring = watchState(recap, Number(recap["clicks"]));
  const cover = watchState(section.frontmatter, 0);
  assert.ok(hairspring && cover);
  assert.equal(stepMove(hairspring, cover, "forward"), "ordered");
  assert.equal(stepMove(cover, hairspring, "back"), "ordered");
});

/** What is on the screen at the start and at the end of the camera's move,
 *  on a step from `from` to `to`, and when the step ends: from the timeline
 *  at 10 ms. */
function aroundMove(
  from: WatchState,
  to: WatchState,
  move: Move,
  moveWith: StepMoveWith,
): {
  start: ReadonlySet<Mesh>;
  end: ReadonlySet<Mesh>;
  after: ReadonlySet<Mesh>;
} {
  const timeline = new Timeline(watch.scene.slide);
  timeline.show(stageState(watch, from, moveWith), 0, true);
  timeline.show(
    stageState(watch, { ...to, move: stepMove(from, to, move) }, moveWith),
    0,
  );
  const moving: number[] = [];
  for (let time = 0; time < timeline.endAt(0); time += 10) {
    const channel = timeline.phaseAt(time);
    if (channel === "view" || channel === "angles" || channel === "camera") {
      moving.push(time);
    }
  }
  const onScreen = (time: number): ReadonlySet<Mesh> => {
    const { keep, fade, rest } = timeline.valuesAt(time);
    return rest > 0 ? new Set([...keep, ...fade]) : keep;
  };
  assert.ok(moving.length > 0, "the camera does not move");
  return {
    start: onScreen(moving[0] ?? 0),
    end: onScreen(moving.at(-1) ?? 0),
    after: timeline.valuesAt(timeline.endAt(0)).keep,
  };
}

test("the Recap slide hides the hour hand from the centre wheel's stop and the minute hand from the third wheel's; the cover's picture brings both back", () => {
  const index = slides.findIndex(({ title }) => title === "Recap");
  const recap = slides[index]?.frontmatter;
  const section = slides[index + 1]?.frontmatter;
  assert.ok(recap && section);
  const hourHand = pieceNamed("hour hand");
  const minuteHand = pieceNamed("minute hand");
  const clicks = Number(recap["clicks"]);
  const at = (click: number) =>
    watchState(recap, click) ?? assert.fail(`Recap @${String(click)}`);
  for (let click = 0; click <= clicks; click++) {
    assert.equal(
      shows(at(click), hourHand),
      click < 3,
      `hour @${String(click)}`,
    );
    assert.equal(
      shows(at(click), minuteHand),
      click < 4,
      `minute @${String(click)}`,
    );
  }
  const cover = watchState(section, 0) ?? assert.fail();
  assert.ok(shows(cover, hourHand) && shows(cover, minuteHand));
  const has = (meshes: ReadonlySet<Mesh>, piece: Piece): boolean =>
    [...piece.meshes].every((mesh) => meshes.has(mesh));
  // each hand goes after the camera arrives at its click, and comes back
  // before it leaves on the step back
  for (const [click, hand] of [
    [3, hourHand],
    [4, minuteHand],
  ] as const) {
    const forward = aroundMove(
      at(click - 1),
      at(click),
      "forward",
      MOVE_WITH_COMMON,
    );
    assert.ok(has(forward.end, hand) && !has(forward.after, hand));
    const back = aroundMove(at(click), at(click - 1), "back", MOVE_WITH_COMMON);
    assert.ok(!has(back.start, hand) && has(back.after, hand));
  }
  // into the cover's picture, both hands come before the camera moves; on
  // the step back, they go after it
  const moveWith = moveWithBefore(section);
  const forward = aroundMove(at(clicks), cover, "forward", moveWith);
  const back = aroundMove(cover, at(clicks), "back", moveWith);
  for (const hand of [hourHand, minuteHand]) {
    assert.ok(has(forward.start, hand), `${hand.name}: forward`);
    assert.ok(has(back.end, hand) && !has(back.after, hand), hand.name);
  }
});
