// The watch's 2D outlines, ported from the Python art (watch_design.py,
// frozen in tasks/2026-09-29-webgl-watch/inputs/art/). Each is a Path, about
// its own origin, in slide px. Angles are screen angles in degrees: 0 is
// 3 o'clock, increasing clockwise, because y points down.

import type { Point2 } from "../webgl/mesh.ts";
import { Path, circlePath } from "./path.ts";

export function radians(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

/** Polar to xy, from `origin`. */
export function polar(
  radius: number,
  angleDegrees: number,
  origin: Point2 = [0, 0],
): Point2 {
  const theta = radians(angleDegrees);
  return [
    origin[0] + radius * Math.cos(theta),
    origin[1] + radius * Math.sin(theta),
  ];
}

/** A clock-face angle (0 = 12 o'clock, clockwise) as a screen angle. */
export function clock(clockAngle: number): number {
  return clockAngle - 90;
}

export function disc(radius: number): Path {
  return circlePath(0, 0, radius);
}

/** An annulus as two subpaths, for the even-odd rule. */
export function ring(outer: number, inner: number): Path {
  return circlePath(0, 0, outer).append(circlePath(0, 0, inner));
}

/** A D: a circle about `centre` cut by a straight flat, `flatOffset` from the
 *  centre, facing the screen angle `facing`. */
export function dShape(
  centre: Point2,
  radius: number,
  flatOffset: number,
  facing: number,
): Path {
  if (!(flatOffset >= 0 && flatOffset < radius)) {
    throw new Error("a D's flat must cut the circle on its own side");
  }
  const half = (Math.acos(flatOffset / radius) * 180) / Math.PI;
  const start = polar(radius, facing + half, centre);
  const end = polar(radius, facing - half, centre);
  // the long way round, clockwise, then the flat back to the start
  return new Path()
    .moveTo(...start)
    .arcTo(radius, true, true, ...end)
    .close();
}

/** A lever escape wheel: club teeth whose locking face leads anticlockwise,
 *  the way this one turns. */
export function escapeOutline(
  teeth: number,
  rootRadius: number,
  tipRadius: number,
  phase = 0,
): Path {
  const toothAngle = -360 / teeth;
  const path = new Path();
  for (let index = 0; index < teeth; index++) {
    const tip = phase + index * toothAngle;
    if (index === 0) path.moveTo(...polar(rootRadius, tip - 0.9 * toothAngle));
    // the back of the tooth curves up to the club; the club's flat top is the
    // impulse face; the locking face drops almost radially
    const [controlX, controlY] = polar(rootRadius + 2, tip - 0.55 * toothAngle);
    path.quadTo(
      controlX,
      controlY,
      ...polar(tipRadius - 2, tip - 0.22 * toothAngle),
    );
    path.lineTo(...polar(tipRadius, tip));
    path.lineTo(...polar(rootRadius, tip + 0.04 * toothAngle));
    path.arcTo(
      rootRadius,
      false,
      false,
      ...polar(rootRadius, tip + 0.1 * toothAngle),
    );
  }
  return path.close();
}

/** The gaps between straight spokes of constant width, one subpath each. */
export function openings(
  spokes: number,
  hubRadius: number,
  rimRadius: number,
  spokeWidth: number,
  phase = 0,
): Path {
  const halfWidth = spokeWidth / 2;
  const edge = (spokeAngle: number, side: number, radius: number): Point2 => {
    const along = Math.sqrt(radius * radius - halfWidth * halfWidth);
    const theta = radians(spokeAngle);
    return [
      along * Math.cos(theta) - side * halfWidth * Math.sin(theta),
      along * Math.sin(theta) + side * halfWidth * Math.cos(theta),
    ];
  };
  const path = new Path();
  for (let index = 0; index < spokes; index++) {
    const spoke = phase + (index * 360) / spokes;
    const nextSpoke = spoke + 360 / spokes;
    path.moveTo(...edge(spoke, 1, rimRadius));
    path.arcTo(rimRadius, false, true, ...edge(nextSpoke, -1, rimRadius));
    path.lineTo(...edge(nextSpoke, -1, hubRadius));
    path.arcTo(hubRadius, false, false, ...edge(spoke, 1, hubRadius));
    path.close();
  }
  return path;
}

/** A closed polygon of straight edges. */
export function polygon(points: Point2[]): Path {
  const [first, ...rest] = points;
  if (first === undefined) throw new Error("a polygon needs points");
  const path = new Path().moveTo(...first);
  for (const point of rest) path.lineTo(...point);
  return path.close();
}

export interface DaggerOptions {
  length: number;
  maxWidth: number;
  /** The widest point, as a fraction of the length. */
  widestAt: number;
  tail: number;
  tailWidth: number;
  /** The hand narrows to `tailWidth` this far from the arbor. */
  neck?: number;
}

/** A hand pointing at 12 from the origin: widest at `widestAt` of its length,
 *  with a short tail. */
export function dagger(options: DaggerOptions): Path {
  const { length, maxWidth, widestAt, tail, tailWidth, neck } = options;
  const side: Point2[] = [[maxWidth / 2, -length * widestAt]];
  if (neck !== undefined) side.push([tailWidth / 2, -neck]);
  side.push([tailWidth / 2, tail]);
  const mirrored = side
    .map(([across, along]): Point2 => [-across, along])
    .reverse();
  return polygon([[0, -length], ...side, ...mirrored]);
}

/** A rectangle with rounded corners, as lines and quarter arcs. */
export function roundedRectangle(
  x: number,
  y: number,
  width: number,
  height: number,
  corner: number,
): Path {
  return new Path()
    .moveTo(x + corner, y)
    .lineTo(x + width - corner, y)
    .arcTo(corner, false, true, x + width, y + corner)
    .lineTo(x + width, y + height - corner)
    .arcTo(corner, false, true, x + width - corner, y + height)
    .lineTo(x + corner, y + height)
    .arcTo(corner, false, true, x, y + height - corner)
    .lineTo(x, y + corner)
    .arcTo(corner, false, true, x + corner, y)
    .close();
}
