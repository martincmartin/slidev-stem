// Stills of the watch, for the pages that must not animate: print and export,
// the overview, the presenter's "next" pane. One hidden renderer draws them
// all (webgl/stills.ts).

import { Stills } from "../webgl/stills.ts";
import { at } from "../webgl/checked.ts";
import type { PoseGroups } from "../webgl/stage.ts";
import type { Palette } from "../webgl/scene.ts";
import type { Watch } from "./generate.ts";
import { linePose, runningSpringPose, stagePose } from "./mainspring.ts";
import { Motion, stillPose } from "./model.ts";
import { stageState } from "./state.ts";
import type { WatchState } from "./state.ts";

/** s: a pose with nothing at a keyframe. */
export const STILL_TIME = 0.37;

export class WatchStills {
  private readonly watch: Watch;
  private readonly poseGroups: PoseGroups;
  private readonly motion: Motion;
  private readonly stills: Stills;

  /** `poseGroups`: the matrices of the scene's groups that follow the
   *  camera (`withPoseGroups`). */
  constructor(watch: Watch, poseGroups: PoseGroups) {
    this.watch = watch;
    this.poseGroups = poseGroups;
    this.motion = new Motion(watch);
    this.stills = new Stills(watch.scene);
  }

  /** Free the renderer and revoke the stills' URLs. */
  dispose(): void {
    this.stills.dispose();
  }

  /** A slide's state as a picture (an object URL) in the slide's palette, at
   *  the still time, or at rest. `size` is in device px. */
  of(
    state: WatchState,
    size: [number, number],
    palette: Palette,
  ): Promise<string> {
    const { design } = this.watch;
    const key = JSON.stringify([
      state.view,
      state.tilt,
      state.turn,
      state.show,
      state.fit,
      state.right,
      state.band,
      state.spin,
      state.settled,
      state.mainspring,
      state.unwind,
      state.dim,
      state.hide,
      size,
    ]);
    return this.stills.of(key, palette, (renderer) => {
      const { time, swing } = stillPose(
        design.timing,
        state.settled,
        STILL_TIME,
      );
      const stage = stageState(this.watch, state);
      const beats = this.motion.beats(time);
      const barrelAngle = at(design.wheels, 0).step * beats;
      // A running spring is wound at the posed barrel position.
      const spring = state.unwind
        ? runningSpringPose(barrelAngle, barrelAngle)
        : state.mainspring === null
          ? linePose(0)
          : stagePose(state.mainspring);
      renderer.updateMesh(this.watch.spring, this.motion.springGeometry(swing));
      renderer.updateMesh(
        this.watch.mainspring,
        this.motion.mainspringGeometry(spring),
      );
      renderer.render({
        view: stage.view,
        tilt: stage.tilt,
        turn: stage.turn,
        groupMatrices: new Map([
          ...this.motion.matrices(time, swing, beats, spring.arbor),
          ...this.poseGroups(stage),
        ]),
        keep: stage.shown,
        rest: 0,
        ...(stage.dim ? { dim: stage.dim } : {}),
        size,
      });
    });
  }
}
