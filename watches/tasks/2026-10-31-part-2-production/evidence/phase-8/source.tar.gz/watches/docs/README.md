# watches: the talk's own docs

What is true of this talk only. The house rules for every STEM talk (theme,
illustrations, WebGL, legibility, how to work in the repo) are in
[`stem/docs/`](../../docs/README.md). When to read each doc is in
[`stem/AGENTS.md`](../../AGENTS.md), "House docs: read before you act"; keep
the two lists in step.

- [slide-patterns.md](slide-patterns.md): how a slide is built: the theme on a
  slide, the timekeeper card, clicks, punchlines, labels on a map, speaker
  notes, what fits, borrowed assets
- [watch.md](watch.md): the live watch (files, a new layer, design, rim
  screws, frontmatter keys, the explorer, zoom line widths, budgets) and the
  diving board
- [globe.md](globe.md): Part 2's globe and story maps: the land data, the
  globe's meshes and levels, its views, the story maps' marks and their
  keys, the labels on them, the flight, and how it joins the watch's scene
- [article.md](article.md): the article at `/article`: the narration, its figure
  markers, what a figure shows, the sliders and the button, the code, the
  Part 2 story figures, the static page, the text export
- [measurements.md](measurements.md): what the timekeepers, the cover watch,
  balance rim motion, and the diving board measure at the back row
- [rough-slides.md](rough-slides.md): the talk's outline, as working notes.
  Check each claim before it goes on a slide
- [packages.md](packages.md): dependency constraints and the UnoCSS build
  override
- [watchlist.md](watchlist.md): the last milestone, and the corrections that
  may come back but have no lesson yet
