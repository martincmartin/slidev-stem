# Navigation: forward and back

**Covers:** how a slide says what it shows, so that going back a click or a
slide works with no extra code; the default for each kind of animation when
the viewer goes back; what a mouse click does; and the check that finds a move
that does not follow the rules.

**Tasks:**
[`full-validation-profile`](../watches/tasks/2026-10-07-full-validation-profile/PLAN.md)
(the fast smoke replacement and measured coverage costs),
[`validation-speed`](../tasks/2026-10-06-validation-speed/PLAN.md)
(the combined navigation and offline walk).

**Read before** you add a click, a slide transition, anything that moves or
fades between clicks or slides, or a control on a slide.

Why, and the options that were compared:
[`watches/tasks/2026-10-04-backward-navigation`](../watches/tasks/2026-10-04-backward-navigation/PLAN.md).
Of the first six bugs that appeared only on some paths to a slide, none was in
the one part that already followed these rules (the watch's stage).

## The rules

**Follow the general rules for clicks and slides** in the `slidev-practices`
skill, "Clicks, slides and going back": the settled screen depends only on the
slide and the click, a slide names targets and not moves, a visual on more than
one slide is one element, and a step animates but a jump does not. In the watch
talk, the phase of a physical process (where the hands and the balance are) is
the one thing that may differ on a settled screen.

**A press during a move.** A step that comes while a move runs is a jump: it
shows its own target at once, in either direction. A move runs until each
layer's change, flash and story animation has ended. A step soon after a press
that jumped is a jump too (the talk sets how soon): a jump leaves nothing that
runs, so without this rule every other press of a burst would animate. So a
viewer who presses until a view shows stops at the place of that view. A step
from a screen at rest animates, as before. Not an oversight: when a press
first ended the running change and then animated its own step, each view
showed only after the deck had left its place, and a viewer who looked for a
view went past it. When each press went on from the screen, a burst built
screens that no place names
([`watches/tasks/2026-10-24-rapid-navigation`](../watches/tasks/2026-10-24-rapid-navigation/PLAN.md)).

**Each kind of animation has a default.**

| Kind                 | What it is for                    | Forward                                      | Back                                                                     |
| -------------------- | --------------------------------- | -------------------------------------------- | ------------------------------------------------------------------------ |
| **Presentation**     | shows what to look at             | an eased move to the target                  | the same move reversed: the same lengths, the steps in the reverse order |
| **Attention cue**    | points to where the view is going | plays on the step into its slide or click    | does not play: zooming out does not need it                              |
| **Text timing**      | keeps text off a moving picture   | the text waits for the camera                | the text waits for the camera, which now moves last                      |
| **Story animation**  | tells a story on a click          | plays forward                                | plays backward, to the earlier click's position on the same clock        |
| **Steady loop**      | a state that moves while it lasts | starts at its boundary                       | starts at its boundary again; it is not played backward                  |
| **Physical process** | a machine that runs on its own    | time goes forward; a mode changes by physics | the same: time goes forward, and the earlier mode comes back by physics  |
| **Slide text**       | the words                         | Slidev (`v-click`)                           | Slidev                                                                   |

Examples in the watch talk (`watches/docs/watch.md`): the fades and the
camera's move and tilt are presentation; the flash is the attention cue; the
diving board's bend and curl, and the edit of its callout's sentence after the
curl, are story animations, and its swing is a steady loop; the watch's
mechanism is a physical process. On the Mainspring slide, the key's turns and
the spring's uncoil are story animations, and the time-lapse is a physical
process. Not an oversight: there, a step back cuts to the earlier click's
pose, and does not play the story backward. A key that unwinds the spring
runs time backward, which a step back should not do
([`watch.md`](../watches/docs/watch.md#the-mainspring-slide)). Text that is part of a story animation runs on
that animation's clock, not on a `v-click`.

## Mouse clicks

A mouse click on the slide goes to the next click or slide, in the slides and
in the presenter view, as in Keynote and PowerPoint. A click never goes back:
during a talk, a stray click must not undo a step. To go back, use the arrow
keys, Slidev's navigation bar or a swipe. A click on the letterbox around the
slide goes forward too. The house theme does this, in
`themes/house/setup/root.ts` and `themes/house/styles/house.css`. Slidev alone
goes forward or back only for a click on the letterbox, by its half: no visitor
expects the place of a click to choose its direction.

A click does not go forward when it is on a link, a button, a form control or
a slider, or when it ends a text selection or a drawing. A slide that adds a
control of its own must use one of these elements or roles, or the click on it
also goes forward.

## Validation: fast smoke navigation

Full validation runs `tools/smokecheck.ts` on the built deck.
Quick validation has no browser walk.
The smoke check blocks outside requests and walks forward through each slide and click in all three supported engines.
It checks startup, page errors and logged errors, each declared next position, and the declared final position.
It rejects navigation stalls and walks that exceed their limit.
It does not wait for animations or compare their settled states.

The house theme supplies `window.slideNavigation()` from
`themes/house/setup/root.ts`. Its type is in `themes/house/navigation.ts`,
which the root's `typecheck` checks the theme against, and which the smoke
check imports. The smoke check also checks the values as it reads them: they
come from a page. It returns the current slide and click,
the current slide's click total, the last slide, and the next position.
These values come from Slidev navigation. The smoke tool uses them to detect early stops.
The observation periods and deadlines are in `tools/smokecheck.ts`.
Use `--browser firefox` or `--browser webkit` to select another engine.
Full validation runs all three engines in fresh non-persistent contexts.
It blocks 2D canvas pixel reads to test compatibility with privacy protection.
This regression check does not reproduce every browser privacy policy.
See [talks.md](talks.md#browser-support) for the browser requirements.

## Diagnostic: exhaustive navigation

Run `tools/navcheck.ts` (`pnpm navcheck`) only when an actual navigation problem is found or suspected.
No validation mode runs it. Do not run it routinely, including before commits
or after ordinary navigation changes.

The diagnostic walks forward and backward, waits for each animation to settle,
and loads each position directly. For a rapid walk, whose presses do not
wait for an animation to end, run `pnpm offline-check <deck> --walk`.
It rejects page errors and logged errors, startup failures, and incomplete walks.
It also fails if:

- a place after a move differs from the same place loaded directly (rule 0);
- a number jumps outside the range between where it was and where it ends (a
  flash of something that should not show);
- a number covers most of its change by the first frame after the key press
  (a cut where a fade should be).

It reads what the deck reports. A talk with layers defines
`window.slideState()`, which returns:

| Field        | What it holds                                                                                                                                            |
| ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `settled`    | names and numbers that must be the same however the place is reached (a view, a phase)                                                                   |
| `continuous` | numbers that must move without a cut (an opacity, a scale, a tilt). Leave out one that is not on the screen: a number that leaves ends at its last value |
| `busy`       | true while a story animation or a camera move runs, or while a press would jump ("A press during a move"), so that the check waits for its end           |

A deck without `slideState` passes with a note.
Only headless screen wake-lock acquisition is stubbed
([talks.md](talks.md#browser-support)); page errors and logged errors still fail.
Give each new layer its fields in the talk's `slideState`, in the same change as the layer.
The watch talk's is `watches/watch/slide-state.ts`.
